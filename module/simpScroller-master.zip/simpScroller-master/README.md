simpScroll.js - A simple scrolling method for mobile
=====================
There are many scrolling plugins for mobile. But they are too large! eg. appframework(jqmobi) - af.scroller.js - 63K!<br>
Oh, guy, I just want to add several simple pages for mobile, my small heart can't bear such a heavy. So, it's necessary to create s simple method for scrolling which doesn't have brilliant effect or complex functions, it's just made for scrolling.

small enough?
---------------------
About 4~5K, and small than 2K after compressing. Not small enough? If you still feel this js is large, ok, I true have smaller one, just contact me with email zhangxinxu@zhangxinxu.com

support
-------------------------
common mobile browser and IE9+/FF/Chrome/... desktop browser

How to use?
-------------------------
<pre>simpScroller(container, options);</pre>

APIs~
--------------------------
As follow:
<pre>
{
    verticalScroll: true,          // scroll for vertical
    horizontalScroll: false,       // scroll for horizontal
    hideScrollBar: false,          // if the scrollbar should be showed
    onScroll: function() {}        // a callback function which is triggered when scrolling
	                               // support a param that represent event object 
}
</pre>
demo
----------------------
You can click <a href="http://htmlpreview.github.io/?https://github.com/zhangxinxu/simpScroller/blob/master/index.html">here</a> to visit. 
more
---------------------
You can click <a href="http://www.zhangxinxu.com/wordpress/?p=3505">here(chinese)</a> to get more information.
License
--------------------------
What's this? ![疑问](http://mat1.gtimg.com/www/mb/images/face/32.gif "疑问表情")